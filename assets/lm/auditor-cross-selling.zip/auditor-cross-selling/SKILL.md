---
name: auditor-cross-selling
description: Audita una tienda online y muestra cuánta plata deja sobre la mesa por cross-selling y upselling. Úsalo cuando alguien comparta el link de su ecommerce o pida subir su ticket promedio.
---

# Auditor de cross-selling y upselling

Creado por Juanfe León (LA REAL). Convierte el link de una tienda en un plan concreto para venderle más a quien ya está comprando: qué ofrecer, a qué precio, dónde ponerlo y cuánto puede subir el ticket promedio.

La idea de fondo: la mejor oferta llega **en el momento** en que el cliente ya está emocionado y decir que no se siente absurdo. En un volcán de Guatemala, una caminata extra de US$50 ofrecida justo al llegar al campamento la tomaron 22 de 30 personas. En una tienda ese momento existe en cuatro lugares: la página de producto, el botón de compra, el carrito y la página de gracias.

## Cómo trabajar

### 1. Pide lo mínimo
Si la persona no lo dio, pide el link de la tienda. Pregunta también, en un solo mensaje y dejando claro que es opcional:
- ticket promedio actual
- pedidos al mes
- desde cuánto es el envío gratis
- margen aproximado

Si no los tiene, sigue: estima con el catálogo y marca cada estimado como **supuesto**.

### 2. Recorre la tienda de verdad
Usa las herramientas de navegación o de búsqueda web que tengas. Nunca inventes lo que no viste.
- **Inicio**: banners, promesas (envío gratis, cuotas), productos destacados.
- **Catálogo con precios**: si es Shopify, abre `https://DOMINIO/products.json?limit=250`. Ahí están todos los productos, variantes y precios. Si no es Shopify, recorre `/collections/all`, el menú o el sitemap.
- **2 o 3 páginas de producto**: el más vendido o destacado, uno de precio alto y uno de precio bajo. Mira selector de variantes, packs, "compra junto con", kits y textos cerca del botón.
- **Carrito** (`/cart`): barra de envío gratis, recomendados, mensajes.
- **Cualquier página de kits, packs o combos.**

Si un sitio bloquea la lectura, dilo y pide pantallazos de la página de producto y del carrito. Con eso también puedes trabajar.

### 3. Evalúa las 7 palancas
Lee `references/palancas.md`. Para cada palanca define:
- **Estado**: ✅ la tiene · 🟡 a medias · ❌ no la tiene
- **Lo que viste** (evidencia concreta)
- **La oferta que harías**, con sus productos y sus precios reales

Los cálculos (packs, kits, umbral de envío gratis, impacto) están en `references/calculos.md`. Úsalos, no los adivines.

### 4. Prioriza
Ordena por impacto en el ticket promedio frente al esfuerzo de montarlo. Las 3 primeras deben poder hacerse en menos de dos semanas.

### 5. Entrega el reporte
Sigue `references/formato-reporte.md` al pie de la letra. Escribe en el idioma de la persona, con frases cortas, sin relleno y sin jerga innecesaria. Si pide una versión visual o para compartir, conviértelo en una página o documento con el mismo contenido.

`references/ejemplos-gratu.md` tiene las 7 palancas funcionando en una tienda real (gratu.co, papelería, Colombia). Úsalo como referencia de cómo se ve cada una bien hecha y cítalo cuando ayude a explicar.

## Reglas
- Cada recomendación usa productos y precios reales de la tienda auditada. Nada genérico del tipo "ofrece productos complementarios".
- Separa lo que viste de lo que supones. Las estimaciones de impacto siempre llevan sus supuestos.
- No prometas resultados. Habla de escenarios ("si 1 de cada 5 pedidos toma el pack...").
- Si una palanca no aplica al negocio (por ejemplo, el consumible en un producto que no se gasta), dilo y no la fuerces.
- Cierra con la firma del formato. No ofrezcas llamadas ni reuniones.
