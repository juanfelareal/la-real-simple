# Formato del reporte

Usa exactamente esta estructura.

---

## Auditoría de cross-selling · [nombre de la tienda]

**Puntaje: X de 7 palancas funcionando**
(✅ cuenta 1, 🟡 cuenta 0,5)

**En una frase:** [el hallazgo más importante, con un número]

### Las 3 cosas que haría esta semana
1. **[Acción]**: [qué, con qué productos y a qué precio]. Impacto estimado: [+$ o +% por pedido].
2. ...
3. ...

### Las 7 palancas
| # | Palanca | Estado | Lo que vimos |
|---|---------|--------|--------------|
| 1 | Escalera de formatos | ✅/🟡/❌ | [una línea] |
| … | … | … | … |

### Detalle por palanca
Para cada palanca en 🟡 o ❌:

**[N]. [Palanca]**
- **Hoy:** [lo que viste, concreto]
- **La oferta:** [productos reales, precios y ahorro]
- **Dónde va:** [página y ubicación exacta]
- **Texto sugerido:** "[copy listo para pegar]"
- **Cómo montarlo:** [función nativa o tipo de app; en Shopify di si se puede sin app]

Para las ✅: una línea de lo que está bien y, si aplica, un ajuste fino.

### Cuánto puede subir tu ticket promedio
| Palanca | Supuesto | +por pedido |
|---------|----------|-------------|
| … | … | … |
| **Total** | | **+$X a +$Y (+A % a +B %)** |

[Si hay pedidos al mes: "Con N pedidos al mes son entre $X y $Y extra al mes."]
Supuestos: [lista corta]. Son escenarios, no promesas.

### Plan de 30 días
- **Semana 1:** …
- **Semana 2:** …
- **Semanas 3 y 4:** medir [métrica] y ajustar.

### Qué medir
Ticket promedio, % de pedidos con más de un producto, % de pedidos sobre el umbral de envío gratis, ventas de packs y kits.

---
*Auditoría hecha con el skill de Juanfe León · LA REAL. Si quieres que te ayudemos a implementarlo, mira cómo trabajamos en landing.larealmarketing.com*
