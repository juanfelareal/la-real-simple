# Las 7 palancas de cross-selling y upselling

Cada palanca vive en un momento distinto de la compra. Upselling = que compre una versión mejor o más cantidad. Cross-selling = que sume otro producto.

## 1. Escalera de formatos (upselling · página de producto)
**Qué es:** el mismo producto en 2 o 3 niveles (básico, mejor, premium) con precios escalonados, visibles en el selector de variantes.
**Por qué funciona:** quien entró por el básico ve el siguiente escalón y lo compara contra el básico, no contra cero. El escalón del medio suele ser el más vendido.
**Qué mirar:** ¿hay variantes de calidad, tamaño o material? ¿Se ven los precios de cada nivel sin hacer clic? ¿El escalón premium existe aunque se venda poco? (sirve de ancla).
**Bien hecha:** 3 niveles, el del medio marcado como "el más elegido" y la diferencia de precio entre niveles de 25 a 60 %.

## 2. Precio por cantidad (upselling · selector de cantidad)
**Qué es:** packs x2 / x3 con precio unitario menor y el ahorro escrito en plata, no solo en %.
**Qué mirar:** ¿hay productos que se regalan, se repiten o se usan en pareja? ¿Existe el pack? ¿Dice "ahorras $X"?
**Bien hecha:** el pack aparece en la misma página de producto, con precio por unidad y ahorro total visibles.

## 3. Complementos junto al botón (cross-selling · página de producto)
**Qué es:** 2 a 4 productos baratos que completan el principal, con un clic para agregarlos, justo cerca del botón de compra.
**Regla de precio:** cada complemento debe costar menos de un 25 a 30 % del producto principal. Así se suma "sin pensarlo".
**Qué mirar:** ¿hay bloque de complementos? ¿Está arriba, cerca del botón, o perdido al final? ¿Se agrega sin salir de la página?

## 4. El kit armado (ambos · menú y combos)
**Qué es:** un conjunto listo (principal + complementos) a un precio menor que la suma, con el ahorro calculado.
**Por qué funciona:** resuelve la decisión completa en un clic y sube el ticket de golpe.
**Qué mirar:** ¿existen kits? ¿Están en el menú? ¿Muestran "por separado $X, en kit $Y"? ¿Hay stock? Un kit agotado es una palanca apagada.
**Bien hecho:** descuento de 10 a 20 % frente a la suma, con nombre propio y foto de todo junto.

## 5. Umbral de envío gratis (ambos · en toda la tienda)
**Qué es:** envío gratis desde un monto un poco por encima del ticket promedio, con una barra de progreso en el carrito ("te faltan $X").
**Qué mirar:** ¿hay umbral? ¿Dónde se comunica? ¿La barra existe y se actualiza? ¿El umbral está bien puesto? (ver cálculos).
**Bien hecho:** se anuncia arriba de la tienda y se repite en el carrito con lo que falta y un producto que lo complete.

## 6. El consumible / recompra (cross-selling · recompra)
**Qué es:** el repuesto, la recarga o la versión que se gasta del producto principal, a precio bajo, ofrecido desde la primera compra.
**Qué mirar:** ¿el producto se gasta, se llena o se renueva? ¿Venden la recarga? ¿La ofrecen en la página del principal y después de la compra?
**Si no aplica:** dilo. Puede reemplazarse por accesorios o por el siguiente producto natural (ej. del año 1 al año 2).

## 7. Recomendados al final y en el carrito (cross-selling · fin de página y carrito)
**Qué es:** "completa tu compra" con productos que tengan sentido juntos, en el carrito y al final de la página de producto.
**Qué mirar:** ¿los recomendados tienen lógica o son aleatorios? ¿Aparecen en el carrito? ¿Hay oferta después de pagar (página de gracias)?

## Bonus: la oferta después de pagar
Un producto con descuento en la página de gracias o en el correo de confirmación, que se agrega sin volver a pagar todo. Es el momento de mayor confianza del cliente. Menciónalo si la tienda no lo tiene, sin contarlo dentro del puntaje de 7.
