# Cálculos

Muestra siempre la cuenta, con los números de la tienda.

## Ticket promedio (si no lo dan)
Estímalo como el precio del producto más destacado o más vendido, más un 15 %. Márcalo como supuesto.

## Umbral de envío gratis
- Ideal: entre 1,2 y 1,4 veces el ticket promedio.
- Prueba práctica: producto estrella + el complemento más barato deben pasar el umbral, o quedar a menos de un producto de pasarlo.
- Si el umbral está por debajo del ticket promedio, la mayoría ya lo pasa sin esfuerzo: súbelo. Si está muy por encima (más de 1,6 veces), casi nadie lo intenta: bájalo o crea un producto puente.

## Packs por cantidad
- x2: entre 8 y 12 % de descuento por unidad. x3: entre 15 y 20 %.
- Escribe el ahorro en plata: "Ahorras $X".

## Kits
- Precio del kit = suma de los productos × (0,80 a 0,90).
- Muestra: "Por separado $A · En kit $B · Ahorras $C".
- Revisa el margen si lo dieron: el descuento no puede comerse más de la mitad del margen.

## Complementos
- Precio de cada complemento ≤ 25 a 30 % del producto principal.

## Impacto estimado en el ticket promedio
Para cada palanca recomendada:

> aumento por pedido = tasa de adopción × valor agregado por quien la toma

Tasas de adopción para escenarios conservadores (úsalas como supuestos, no como promesas):
- Complementos junto al botón: 8 a 15 %
- Packs por cantidad: 5 a 12 %
- Kit armado: 5 a 10 % de quienes compran el principal
- Barra de envío gratis bien puesta: 10 a 20 % de los pedidos que quedan cerca del umbral
- Oferta después de pagar: 3 a 8 %

Suma las palancas, presenta un rango (bajo y alto) y, si hay pedidos al mes, multiplícalo para mostrar plata extra al mes. Aclara que son escenarios.
