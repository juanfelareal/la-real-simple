# Las 7 palancas en una tienda real: gratu.co

GRATU vende planeadores y papelería en Colombia. Precios en pesos colombianos tomados de gratu.co en noviembre de 2026; pueden haber cambiado.

1. **Escalera de formatos.** El mismo planeador semanal en tres niveles: $39.900, acrílico $49.900 y cosido $59.900. Quien llega por el básico ve el siguiente escalón en el mismo producto, y el selector de formato muestra cosido o recargable.
2. **Precio por cantidad.** Pack x3 a $47.920 cada uno: "Ahorra $35.940 · 20 %". El ahorro va en plata, no solo en porcentaje.
3. **Complementos junto al botón.** "Complementa tu sistema": cuatro blocs de $13.930, menos de un cuarto del producto principal, agregables desde la misma página.
4. **El kit armado.** Focus Reset Kit (planeador, recarga y tres blocs) a $84.900 frente a $100.590 por separado: 15 % de ahorro, ya calculado. Lección: cuando el kit se agota, la palanca se apaga; hay que cuidar su stock.
5. **Umbral de envío gratis.** Envío gratis desde $99.000 con barra de progreso real en el carrito ("te faltarían $39.100"). Ningún producto suelto lo alcanza: invita a combinar.
6. **El consumible.** Recarga de hojas a $18.900 y lapicero a $7.000. El planeador se compra una vez; las hojas se acaban.
7. **Recomendados al final.** "Completa tu escritorio": otros productos para quien leyó hasta abajo y aún no decidió.
