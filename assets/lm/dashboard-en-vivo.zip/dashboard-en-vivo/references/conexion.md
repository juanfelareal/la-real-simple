# Cómo conectar Shopify y Meta Ads en Claude

Explícale a la persona solo lo que le falta, en pasos cortos.

## Shopify (obligatorio)
1. En un chat de Claude, toca el **+** de abajo a la izquierda › **Conectores** › **Administrar conectores** (en inglés: Connectors › Manage connectors).
2. Toca el **+** junto a Conectores, busca **Shopify** y toca **Conectar**.
3. Inicia sesión con la cuenta de Shopify de la tienda. Debe tener acceso a analítica y a pedidos (dueño o colaborador con esos permisos).
4. Vuelve al chat y verifica que Shopify esté activado en **+ › Conectores**.

## Meta Ads (recomendado)
Meta tiene un conector oficial que se agrega como conector personalizado:
1. En Claude, ve a **Conectores** (en la configuración) › **+** › **Agregar conector personalizado**.
2. Nombre: `Meta Ads`. URL: `https://mcp.facebook.com/ads`. Toca **Agregar**.
3. Toca **Conectar**, inicia sesión con Facebook y elige el portafolio comercial donde está la cuenta publicitaria.
4. En el chat, actívalo en **+ › Conectores**.

Ten en cuenta:
- El conector de Meta está en beta abierta. Si la cuenta aparece pero no deja consultar datos, la herramienta devuelve la razón; muéstrasela a la persona.
- En el plan gratis de Claude se puede tener un conector personalizado a la vez. En planes Team o Enterprise, el administrador lo habilita primero para la organización.
- El conector de Meta también puede crear y editar anuncios. Este skill solo lee datos y nunca cambia nada.

## Si algo no funciona
- **"Necesita iniciar sesión"**: vuelve a Conectores y toca Conectar otra vez.
- **No aparece la tienda o la cuenta**: revisa que la cuenta con la que entraste tenga acceso.
- **Las cifras no cuadran con Shopify**: revisa la zona horaria y que estés comparando venta neta (no ventas totales).
