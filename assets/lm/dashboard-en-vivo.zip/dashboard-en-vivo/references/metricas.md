# Métricas y consultas

Fechas: `INICIO` y `FIN` son las de la campaña. `HOY` es la fecha de hoy en la zona horaria de la tienda. Toma la moneda y la zona horaria de la información de la tienda (herramienta de información de Shopify) antes de consultar.

## Shopify · analítica (ShopifyQL)

Pasa solo el cuerpo de la consulta, empezando por `FROM`. Una consulta por llamada. Si una consulta devuelve error de sintaxis o de columna, no adivines: busca en la documentación de ShopifyQL con la herramienta de búsqueda de documentos de Shopify (por ejemplo "ShopifyQL sales schema metrics dimensions" o "ShopifyQL TIMESERIES hour") y corrige.

| Dato del tablero | Consulta |
|---|---|
| Venta neta, pedidos y ticket de la campaña | `FROM sales SHOW net_sales, orders, average_order_value SINCE INICIO UNTIL HOY` |
| Hoy hasta ahora | `FROM sales SHOW net_sales, orders SINCE today UNTIL today` |
| Pedidos de clientes nuevos | `FROM sales SHOW orders GROUP BY new_or_returning_customer SINCE INICIO UNTIL HOY` → % = pedidos de "Nuevo" ÷ total |
| Venta neta por día | `FROM sales SHOW net_sales TIMESERIES day SINCE INICIO-7d UNTIL FIN` (los días futuros van en `null`) |
| Promedio de un día normal | `FROM sales SHOW net_sales TIMESERIES day SINCE INICIO-30d UNTIL INICIO-1d` → promedio de los 30 días |
| Pulso por hora de hoy | `FROM sales SHOW net_sales TIMESERIES hour SINCE today UNTIL today` |
| Hora normal | la misma consulta por hora para los 14 días antes de `INICIO`, y promedias cada hora (0 a 23) |
| Productos estrella | `FROM sales SHOW net_items_sold GROUP BY product_title SINCE INICIO UNTIL HOY ORDER BY net_items_sold DESC LIMIT 10` |

Si la granularidad por hora no está disponible en esa tienda, arma el pulso por hora con los pedidos de hoy (consulta GraphQL de abajo, con `first: 250` y filtro `created_at:>=HOY`), sumando el subtotal por hora de creación. Avísalo en el tablero.

Para fechas usa el formato `2026-11-21`. Si la campaña aún no empieza, usa los últimos 7 días como "campaña" y dilo.

## Shopify · pedidos recientes (GraphQL)

```graphql
{
  orders(first: 6, sortKey: CREATED_AT, reverse: true) {
    nodes {
      name
      createdAt
      currentSubtotalPriceSet { shopMoney { amount currencyCode } }
      subtotalLineItemsQuantity
      customer { numberOfOrders }
    }
  }
}
```

- `monto` = `currentSubtotalPriceSet` (sin envío). `productos` = `subtotalLineItemsQuantity`.
- `cliente_nuevo` = `customer.numberOfOrders` es 1.
- `hace_min` = minutos entre `createdAt` y ahora.
- No pidas ni muestres nombre, correo, teléfono ni dirección del cliente.
- Si la herramienta GraphQL no está o falla por permisos, quita el bloque de pedidos recientes (deja `pedidos_recientes: []`) y sigue.

## Meta Ads · inversión

1. Busca las cuentas con la herramienta de cuentas publicitarias. Usa solo cuentas que se puedan consultar; si una no se puede, explica la razón que devuelve la herramienta.
2. Antes de pedir campos, verifícalos con la herramienta de contexto de campos (es obligatorio en el conector oficial de Meta).
3. Consulta a nivel de cuenta, con `time_range` de `INICIO` a `HOY`:
   - `amount_spent` → `totales.inversion`
   - opcional: `omni_purchase` (compras que reporta Meta), `omni_purchase_values` y `purchase_roas` (ROAS de Meta)
4. Para inversión por día usa `time_increment: "1"`.

Meta puede tardar en reportar la última hora. Si la inversión de hoy parece incompleta, dilo.

## Cálculos

- `ticket` = venta neta ÷ pedidos (lo calcula la plantilla).
- `ROAS de la tienda` = venta neta de Shopify ÷ inversión total (lo calcula la plantilla). Con una sola decimal y "x".
- `Venta vs. día normal` = venta de hoy ÷ promedio de un día normal (lo calcula la plantilla). Si hoy va a mitad del día, compara también contra lo que normalmente llevas a esta hora y dilo en las observaciones.
- `cumplimiento` = venta neta ÷ meta (si hay meta).

## Objeto DATA

```json
{
  "tienda": "Nombre de la tienda",
  "moneda": "COP", "locale": "es-CO",
  "campana": { "etiqueta": "Temporada 2026", "nombre": "Black Friday · Cyber Monday", "detalle": "Black Friday vie 27 nov · Cyber Monday lun 30 nov", "inicio": "2026-11-21", "fin": "2026-11-30" },
  "actualizado": "2026-11-24T10:46:00-05:00",
  "totales": { "venta_neta": 0, "pedidos": 0, "inversion": 0, "clientes_nuevos_pct": 0.0, "meta": null },
  "hoy": { "venta_neta": 0, "pedidos": 0 },
  "promedio_dia_antes": 0,
  "por_dia": [ { "fecha": "2026-11-14", "venta_neta": 0, "en_campana": false } ],
  "hora_actual": 10,
  "por_hora": [0, 0, 0],
  "hora_normal": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "pedidos_recientes": [ { "numero": "#1321", "monto": 0, "productos": 1, "cliente_nuevo": true, "hace_min": 5 } ],
  "productos": [ { "nombre": "Producto", "unidades": 0 } ],
  "fuentes": "Shopify (ventas y pedidos) · Meta Ads (inversión)",
  "fuentes_inversion": "Meta Ads"
}
```

- `por_hora` lleva solo las horas que ya pasaron (de la 0 a la actual).
- `inversion: null` si no hay Meta conectado. La plantilla muestra "—".
- Usa `locale` según el país de la tienda (`es-CO`, `es-MX`, `es-ES`, `en-US`…).
