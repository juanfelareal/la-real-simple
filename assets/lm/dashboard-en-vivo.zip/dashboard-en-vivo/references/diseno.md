# Diseño del tablero

La plantilla `assets/dashboard.html` ya trae el diseño. Tu trabajo es llenar `DATA` con datos reales. Así se lee cada bloque:

1. **Encabezado**: etiqueta de la temporada, nombre de la campaña, fechas clave y la hora de la última actualización.
2. **Bloque principal (oscuro)**:
   - "EN VIVO" mientras la campaña está activa. Antes o después de la campaña dice "CAMPAÑA".
   - Venta neta en campaña, en grande. Debajo: pedidos, ticket y ROAS de la tienda.
   - Hoy hasta ahora, inversión en campaña y venta de hoy frente a un día normal.
   - Pedidos recientes: los últimos 6, sin datos personales.
3. **Fila de indicadores**: pedidos, ROAS de la tienda, % de pedidos de clientes nuevos y cumplimiento de la meta.
4. **Venta neta por día**: barras claras antes de la campaña, verdes durante la campaña, y la línea punteada del día normal.
5. **Pulso por hora**: las horas de hoy contra la hora normal. La barra de la hora en curso va más clara.
6. **Productos estrella**: los 10 más vendidos en unidades.

## Reglas
- No cambies colores, tipografías ni el orden de los bloques salvo que la persona lo pida.
- Si falta un dato, deja `null` y la plantilla muestra "—". Nunca rellenes con estimados sin decirlo.
- Si no hay Meta conectado, `inversion: null`; el ROAS sale en "—" y en las observaciones explicas que se activa al conectar la cuenta publicitaria.
- Si la persona pide su marca (logo o colores), cámbialos en las variables de `:root` y conserva lo demás.
- Si pide varias tiendas o marcas, repite la consulta por tienda y agrega al final una tabla "Marca por marca" (venta neta, pedidos, ticket, ROAS), ordenada por venta neta.
