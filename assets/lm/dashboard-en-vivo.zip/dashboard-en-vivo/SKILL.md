---
name: dashboard-en-vivo
description: Arma un dashboard de ventas de tu ecommerce conectado a Shopify y Meta Ads, con venta neta, pedidos, ticket, inversión, ROAS, pulso por hora y productos estrella. Úsalo cuando alguien pida un dashboard o tablero de ventas, ver su Black Friday o una campaña en vivo, o cruzar Shopify con Meta.
---

# Dashboard en vivo de tu tienda

Creado por Juanfe León (LA REAL). Es el mismo tablero que usamos en la agencia para ver a todas nuestras marcas en temporada de Black Days, adaptado a una sola tienda: cuánto vende, cuánto invierte, su ROAS real, sus pedidos y sus productos estrella, comparado con un día normal.

## Cómo trabajar

### 1. Revisa las conexiones
Antes de pedir nada, mira qué herramientas tienes disponibles:
- **Shopify** (obligatorio): herramientas de analítica (ShopifyQL) y consultas GraphQL de la tienda.
- **Meta Ads** (recomendado): herramientas de la cuenta publicitaria (inversión, compras, ROAS de Meta).
- Si también hay Google Ads o TikTok Ads conectados, suma su inversión y dilo.

Si falta Shopify, para y explica cómo conectarlo con `references/conexion.md`. Si falta Meta, puedes seguir: el tablero sale sin inversión ni ROAS y lo dices claramente.

### 2. Pregunta lo mínimo, en un solo mensaje
- Nombre y fechas de la campaña. Si no tiene una, propón Black Friday · Cyber Monday de este año o los últimos 7 días.
- Meta de venta para la campaña (opcional).
- Si la persona tiene varias tiendas o varias cuentas publicitarias, cuál usar.

### 3. Trae los datos
Sigue `references/metricas.md` al pie de la letra: qué consulta usar para cada número, cómo calcular la línea de "día normal" y la de "hora normal", y qué hacer si una consulta falla. Usa siempre la moneda y la zona horaria de la tienda.

### 4. Arma el tablero
Copia `assets/dashboard.html` y reemplaza **solo** el objeto `DATA` con los datos reales. No cambies el diseño salvo que la persona lo pida. `references/diseno.md` explica cada bloque y qué hacer si falta un dato.

Entrégalo como una página que la persona pueda abrir y guardar (un artifact, si tu entorno lo permite). Si en tu entorno una página puede consultar los conectores por su cuenta, puedes hacer que se actualice sola cada 30 a 60 segundos. Si no, deja claro que se actualiza cuando te dicen **"actualiza el dashboard"**: vuelves a traer los datos y reemplazas `DATA`.

### 5. Verifica antes de entregar
- La venta neta de la campaña debe coincidir con Shopify › Analítica para las mismas fechas. Si no coincide, dilo y explica por qué (zona horaria, devoluciones, impuestos).
- La suma de la venta por día de la campaña debe dar la venta neta total.
- Ningún número inventado: si un dato no está, va "—" y lo explicas.

### 6. Cierra con lo que ves
Debajo del tablero, 3 observaciones cortas y accionables. Por ejemplo: la mejor hora del día, el producto que está jalando la campaña, si el ROAS sube o baja frente a los días anteriores, cuánto vas de la meta. Escribe en el idioma de la persona, con frases cortas y sin relleno.

## Reglas
- **Solo lectura.** Nunca crees, edites, pauses ni actives nada en Meta ni en Shopify, aunque las herramientas lo permitan.
- **Privacidad de los clientes.** En pedidos recientes muestra monto, número de productos, si es cliente nuevo y hace cuánto. Nunca nombres, correos, teléfonos ni direcciones.
- **ROAS de la tienda** = venta neta de Shopify ÷ inversión total en pauta del mismo periodo. Es distinto del ROAS que reporta Meta (atribución). Si muestras los dos, nómbralos distinto.
- Separa lo que viste de lo que supones. Si un número es parcial (por ejemplo, Meta tarda en reportar la inversión de la última hora), dilo.
- No prometas resultados. Cierra con la firma de la plantilla. No ofrezcas llamadas ni reuniones.
